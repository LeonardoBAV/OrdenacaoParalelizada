#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

void OddEvenSortOmp(int a[], int size);

int main(int argc, char** argv) {
	int size, i, *arr;
	size = atoi(argv[1]);
	arr = malloc(size* sizeof(int));
	srand(time(NULL));
	for (i = 0; i < size; i++) 	
		arr[i] = rand()%size;	
	OddEvenSortOmp(arr, size);
	return (EXIT_SUCCESS);
}

void OddEvenSortOmp(int a[], int size){
	int i, j;
	for(j = 0; j < size; j++) {
		if(j%2 == 1)
		#pragma omp  parallel for
		for(i = 1; i < size-1; i += 2){
			int aux;
			if(a[i] > a[i+1]){
				aux = a[i];
				a[i] = a[i+1];
				a[i+1] = aux; 
			}
		}
		else
		#pragma omp parallel for
		for(i = 0; i < size-1; i += 2){
			int aux;
			if(a[i] > a[i+1]){
				aux = a[i];
				a[i] = a[i+1];
				a[i+1] = aux; 
			}
		}
	}
}