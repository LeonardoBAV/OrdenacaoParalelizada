#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

void QuickSortOmp(int arr[], int left, int right, int thread);
void Swap(int* a, int* b);
int Partition(int vec[], int left, int right);
void QuickSort(int vec[], int left, int right);

int main(int argc, char** argv) {
	int size, i, *arr;
	size = atoi(argv[1]);
	arr = malloc(size* sizeof(int));
	srand(time(NULL));
	for (i = 0; i < size; i++) 	
		arr[i] = rand()%size;	
	QuickSortOmp(arr,0 , size-1, omp_get_max_threads());
	return (EXIT_SUCCESS);
}

void QuickSortOmp(int arr[], int left, int right, int thread) {
	int r;
	if (right > left) {
		r = Partition(arr, left, right);
		if(thread > 1){
			 #pragma omp parallel sections
			{
				#pragma omp section
				{
					QuickSortOmp(arr, left, r - 1, thread/2);
				}
				#pragma omp section
				{
					QuickSortOmp(arr, r + 1, right, thread/2);
				}
			}			
		} else {
			QuickSort(arr, left, r - 1);
			QuickSort(arr, r + 1, right);
		}
	}	
}

void Swap(int* a, int* b) {
	int tmp;
	tmp = *a;
	*a = *b;
	*b = tmp;
}
 
int Partition(int vec[], int left, int right) {
	int i, j;
	i = left;
	for (j = left + 1; j <= right; ++j) {
		if (vec[j] < vec[left]) {
			++i;
			Swap(&vec[i], &vec[j]);
		}
	}
	Swap(&vec[left], &vec[i]);
	return i;
}
 
void QuickSort(int vec[], int left, int right) {
	int r;
 
	if (right > left) {
		r = Partition(vec, left, right);
		QuickSort(vec, left, r - 1);
		QuickSort(vec, r + 1, right);
	}
}
