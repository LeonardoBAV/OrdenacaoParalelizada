#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

void SelectionSortOmp(int *array, int size);

int main(int argc, char** argv) {
	int size, i, *arr;
	size = atoi(argv[1]);
	arr = malloc(size* sizeof(int));
	srand(time(NULL));
	for (i = 0; i < size; i++) 	
		arr[i] = rand()%size;	
	SelectionSortOmp(arr, size);
	return (EXIT_SUCCESS);
}

void SelectionSortOmp(int *array, int size) {
	int i, j, min;
	for (i = 0; i < (size-1); i++) {
		min = i;
		#pragma omp parallel
		{ 
			int local_min = i;
			#pragma omp for
			for (j = (i+1); j < size; j++){
				if(array[j] < array[local_min]) 
					local_min = j;
			}
			#pragma omp critical
			if(array[local_min] < array[min])
				min = local_min;
		}
		if (i != min) {
			int swap = array[i];
			array[i] = array[min];
			array[min] = swap;
		}
	}
}