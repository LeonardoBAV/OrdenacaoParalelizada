#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

void ShellSortOmp(int arr[], int n);
void ShellSortInsertionSort(int arr[], int n, int stride);

int main(int argc, char** argv) {
	int size, i, *arr;
	size = atoi(argv[1]);
	arr = malloc(size* sizeof(int));
	srand(time(NULL));
	for (i = 0; i < size; i++) 	
		arr[i] = rand()%size;	
	ShellSortOmp(arr, size);
	return (EXIT_SUCCESS);
}

void ShellSortInsertionSort(int arr[], int n, int stride) {
	int j;
	for (j=stride; j<n; j+=stride) {
		int key = arr[j];
		int i = j - stride;
		while (i >= 0 && arr[i] > key) {
			arr[i+stride] = arr[i];
			i-=stride;
		}
		arr[i+stride] = key;
	}
}

void ShellSortOmp(int arr[], int n){
	int i, m;
	for(m = n/2; m > 0; m /= 2){
		#pragma omp parallel for shared(arr,m,n) private (i) default(none)
		for(i = 0; i < m; i++)
			ShellSortInsertionSort(&(arr[i]), n-i, m);
	}
}