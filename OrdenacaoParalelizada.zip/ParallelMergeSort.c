#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

void MergeSortOmp(int arr[], int size, int thread);
void Merge(int vec[], int vecSize);
void MergeSort(int vec[], int vecSize);

int main(int argc, char** argv) {
	int size, i, *arr;
	size = atoi(argv[1]);
	arr = malloc(size* sizeof(int));
	srand(time(NULL));
	for (i = 0; i < size; i++) 	
		arr[i] = rand()%size;	
	MergeSortOmp(arr, size, omp_get_max_threads());
	return (EXIT_SUCCESS);
}

void MergeSortOmp(int arr[], int size, int thread){
	int mid;
	if(size > 1) {
		mid = size / 2;
		if(thread > 1) {
			 #pragma omp parallel sections
			{
				#pragma omp section
				{
					MergeSortOmp(arr, mid, thread/2);
				}
				#pragma omp section
				{
					MergeSortOmp(arr + mid, size - mid, thread/2);
				}
			}
		} else {
			MergeSort(arr, mid);
			MergeSort(arr + mid, size - mid);		
		}
		Merge(arr, size);
	}
}

void Merge(int vec[], int vecSize) {
	int mid;
	int i, j, k;
	int* tmp;
 
	tmp = (int*) malloc(vecSize * sizeof(int));
	if (!tmp) 
		exit(1);
 
	mid = vecSize / 2;
 
	i = 0;
	j = mid;
	k = 0;
	
	while (i < mid && j < vecSize) {
		if (vec[i] < vec[j]) 
			tmp[k] = vec[i++];
		else 
			tmp[k] = vec[j++];
		++k;
	}
	
	if (i == mid) 
		while (j < vecSize) 
			tmp[k++] = vec[j++];	
	else 
		while (i < mid) 
			tmp[k++] = vec[i++];
	
	for (i = 0; i < vecSize; ++i) 
		vec[i] = tmp[i];
	
	free(tmp);
}
 
void MergeSort(int vec[], int vecSize) {
	int mid;
 
	if (vecSize > 1) {
		mid = vecSize / 2;
		MergeSort(vec, mid);
		MergeSort(vec + mid, vecSize - mid);
		Merge(vec, vecSize);
	}
}
